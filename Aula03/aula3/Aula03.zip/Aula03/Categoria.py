class Categoria:
    def __init__(self,nome):
        self.id = None
        self.nome = nome
        